set -eu
cd /home/lvx/LVX/lumvorax2

echo === STEP 1 OVERWRITE 5 PATCHED FILES ===
cp /tmp/c125_payload/asic_btc_optimizer.c   src/asic_simulation/asic_btc_optimizer.c
cp /tmp/c125_payload/asic_btc_optimizer.h   src/asic_simulation/asic_btc_optimizer.h
cp /tmp/c125_payload/nx48_btc_controller.c  src/advanced_calculations/bitcoin_quantum_mining/src/nx48_btc_controller.c
cp /tmp/c125_payload/nx48_btc_controller.h  src/advanced_calculations/bitcoin_quantum_mining/src/nx48_btc_controller.h
cp /tmp/c125_payload/main_btc_mining.c      src/advanced_calculations/bitcoin_quantum_mining/src/main_btc_mining.c

echo === STEP 2 VERIF PATCHES PRESENTS ===
grep -c asic_btc_optimizer_tune_full src/asic_simulation/asic_btc_optimizer.c
grep -c BTC_TUNE_FULL src/advanced_calculations/bitcoin_quantum_mining/src/main_btc_mining.c
grep -c BTC_MEM_TRACE_GRANULARITY src/advanced_calculations/bitcoin_quantum_mining/src/main_btc_mining.c
grep -c nx48_ctrl_delta_nx48_initial_milli src/advanced_calculations/bitcoin_quantum_mining/src/nx48_btc_controller.c

echo === STEP 3 BUILD ===
cd src/advanced_calculations/bitcoin_quantum_mining
make clean 2>&1 | tail -3 || true
make -j4 2>&1 | tail -60
ls -la btc_mining_runner 2>&1
md5sum btc_mining_runner 2>&1

echo === STEP 4 RUN BTC_TUNE_FULL=1 BTC_MEM_TRACE_GRANULARITY=bit ===
cd /home/lvx/LVX/lumvorax2
mkdir -p src/advanced_calculations/bitcoin_quantum_mining/logs/c125_real
export BTC_TUNE_FULL=1
export BTC_MEM_TRACE=1
export BTC_MEM_TRACE_GRANULARITY=bit
export BTC_REASONING_TRACE=1
export BTC_LUM_LOG=1
timeout 900 ./src/advanced_calculations/bitcoin_quantum_mining/btc_mining_runner --mode BENCHMARK --threads 4 --duration-s 30 --log-dir src/advanced_calculations/bitcoin_quantum_mining/logs/c125_real 2>&1 | tail -250

echo === STEP 5 ARTEFACTS C125 BIT ===
ls -la src/advanced_calculations/bitcoin_quantum_mining/logs/c125_real/modules/ 2>&1 | tail -20
echo === TAILLE LUMS ===
du -sh src/advanced_calculations/bitcoin_quantum_mining/logs/c125_real/modules/*.lum 2>&1 | head -10
