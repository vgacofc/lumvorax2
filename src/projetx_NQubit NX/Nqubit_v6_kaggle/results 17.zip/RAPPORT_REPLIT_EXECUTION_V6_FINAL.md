# RAPPORT REPLIT EXECUTION V6 FINAL

## 1) Intégrité manifest V6
- Manifest: `results/manifest_forensic_v6.json`
- Verify exit code: 0
```
artifact_count=7
missing=0
mismatches=0
```

## 2) Capture hardware réelle
- report_file: `results/ADC_REAL_HARDWARE_CAPTURE_V6.json`
- goal: `real_hardware_capture_on_replit`
- timestamp_utc: `2026-03-01T14:51:34Z`
- source=/dev/hwrng size=0 read_elapsed_s=None bytes_per_sec=None error=[Errno 2] No such file or directory: '/dev/hwrng'
- source=/dev/random size=32768 read_elapsed_s=9.458199997425254e-05 bytes_per_sec=346450698.95878947 error=None
- source=/dev/urandom size=32768 read_elapsed_s=9.154899998975452e-05 bytes_per_sec=357928541.03995836 error=None
- jitter samples=50000 elapsed_s=0.0072638529999835555 ops_per_sec=6883399.20977382 nqubit_per_sec_proxy=6883399.20977382 mean_ns=145.26656 stddev_ns=277.9947706446407

## 3) Métriques système/hardware complètes
- cpu_count=4
- platform=Linux-6.6.113+-x86_64-with-glibc2.35
- loadavg={'load_1m': 0.1904296875, 'load_5m': 0.18896484375, 'load_15m': 0.09912109375}
- disk_root={'total_bytes': 8656922775552, 'used_bytes': 7164902604800, 'free_bytes': 1492003393536}
- cpu_stat={'cpu_total_ticks': 157236, 'cpu_idle_ticks': 151794}
- mem_total=32873508 kB mem_available=31391560 kB mem_free=28961536 kB

## 4) Stress telemetry
```
# V6 STRESS TELEMETRY
workers=64
duration_s=4
cpu_pressure_estimated_pct=100.00
memory_peak_pct=5.44
target_pct=99.00
status=TARGET_REACHED

```

## 5) Conclusion
- GO technique V6 si verify=0 et au moins une source hardware capturée sans erreur.
- ADC physique certifiée laboratoire: NON (ce run est environnement Catlin/Kaggle/Replit).
